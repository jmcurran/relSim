# relSim 0.3.5

* Added a `NEWS.md` file to track changes to the package.
* Changed version number format.
* Fixed issue with package documentation.
