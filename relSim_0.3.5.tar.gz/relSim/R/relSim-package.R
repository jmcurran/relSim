#' @keywords internal
"_PACKAGE"

## usethis namespace: start
## usethis namespace: end
#' @useDynLib relSim, .registration = TRUE
NULL
